package BT_20_12.Management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
